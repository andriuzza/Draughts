﻿using System;

namespace Draught
{
    class Program
    {
        static void Main(string[] args)
        {
            Game Draught = new Game(new Board(8, 12));
            Draught.PlayGame();    
        }
    }
    public class Board
    {
        private byte Width { get; set; }
        private byte Figure { get; set; }
        private int[,] BoardValue = null; /*the values of every board's  square*/
        public byte WhiteFigures { get; set; } = 0;// - 1
        public byte BlackFigures { get; set; } = 0;// - 2

        public int CrossCount { get; private set; } = 0;

        public Board(byte size, byte figure)
        {
            Width = size;
            Figure = figure;
            FillSquareInitialize(BoardValue, Width);
        }

        private void FillSquareInitialize(int[,] Board, byte Width)  /*BLACK - 2, WHITE - 1 */
        {
            BoardValue = new int[Width + 1, Width + 1];
            bool Has = false;
            for (var i = 1; i <= Width; i++)
            {
                
                for (var j = 1; j <= Width; j++) {
                    if (WhiteFigures == Figure)
                    {
                        Has = true;
                        break;
                    }
                    BoardValue[i, j] = (i + j) % 2 == 0 ? 1 : 0;
                    if (BoardValue[i, j] == 1) { WhiteFigures++; }
                }
                if (Has == true) { Has = false; break; }
            }

            for (var i = Width; i >= 1; i--)
            {
                for (var j = Width; j >= 1; j--)
                {
                    if (BlackFigures == Figure)
                    {
                        Has = true;
                        break;
                    }
                    BoardValue[i, j] = (i + j) % 2 == 0 ? 2 : 0;
                    if (BoardValue[i, j] == 2) { BlackFigures++; }

                }
                if (Has == true) { break; }
            }
            for(var i = 1; i<=Width; i++) { BoardValue[i, 0] = -1; }
        }
        private void CheckIfGameIsOver()
        {
            if (BlackFigures == 0 || WhiteFigures == 0)
            {
                int Player = BlackFigures != 0 ? 2 : 1;
                Console.WriteLine("The Game is Over, Player won {0} the game!", Player);
                Environment.Exit(0);
            }

        }
        public bool CheckIfIsItAllowedToMove(int FigureNumber, Tuple<int, int> From, Tuple<int, int> To)
        {
            if (To.Item1 > 8 || To.Item2 > 8 || To.Item1 == 0 || To.Item2 == 0 ) { return false; }

                if (BoardValue[From.Item1, From.Item2] == FigureNumber)
            {
                if(Math.Abs(From.Item1 - To.Item1) == 2)
                {
                    CrossingFigure(FigureNumber, From, To);
                }
                if ((From.Item1 + 1 == To.Item1 && From.Item2 + 1 == To.Item2 ||
                   From.Item1 + 1 == To.Item1 && From.Item2 - 1 == To.Item2)
                   && BoardValue[To.Item1, To.Item2] == 0 && FigureNumber == 1)
                {
                    BoardValue[From.Item1, From.Item2] = 0;
                    BoardValue[To.Item1, To.Item2] = FigureNumber;
                    return true;
                }
                if ((From.Item1 - 1 == To.Item1 && From.Item2 - 1 == To.Item2 ||
                 From.Item1 - 1 == To.Item1 && From.Item2 + 1 == To.Item2)
                 && BoardValue[To.Item1, To.Item2] == 0 && FigureNumber == 2)
                {
                    BoardValue[From.Item1, From.Item2] = 0;
                    BoardValue[To.Item1, To.Item2] = FigureNumber;
                    return true;
                }
                return false;
            }
            return false;
        }
        /*PIZDA CIA REKURSIJA, HUI CIA JI NRML VEIKS BL.... */
        public bool CrossingFigure(int FigureNumber, Tuple<int, int> From, Tuple<int, int> To)
        {
           if(To.Item1 > 6 || To.Item2 > 6 || To.Item1 == 0 || To.Item2 == 0) { return false; }
          

            if (From.Item1 + 2 == To.Item1 || From.Item1 - 2 == To.Item1)
                for(var i = -1; i <=1; i++)
                {
                    for(var j = -1; j <= 1; j++)
                    {
                        if ((From.Item1 + i < Width + 1 && From.Item1 + i >= 1) && (From.Item2 + j < Width + 1 && From.Item2 + j >= 1) )
                        {
                            if (BoardValue[From.Item1 + i, From.Item2 + j] != FigureNumber
                               && BoardValue[From.Item1 + i, From.Item2 + j] != 0
                               && BoardValue[From.Item1 + (i * 2), From.Item2 + (j * 2)] == 0)
                            {
                                if (CrossCount == 0)/*The first time crossing a figure*/
                                {
                                    BoardValue[From.Item1 + (i * 2), From.Item2 + (j * 2)] = FigureNumber;
                                    BoardValue[From.Item1, From.Item2] = 0;
                                    BoardValue[From.Item1 + i, From.Item2 + j] = 0;

                                    if (FigureNumber == 1) { BlackFigures--; }
                                    else { WhiteFigures--; }

                                    CheckIfGameIsOver(); /*If the game is not over yet */

                                    CrossCount++;
                                    for (int d = 1; d <= Width; d++) /*CHECKING IF THERE ARE MORE CROSSINGS */
                                    {
                                        ///if(To.Item1 + 2 > 8) { continue; }
                                        if (CrossingFigure(FigureNumber, To, new Tuple<int, int>(To.Item1 + 2, d))
                                             || CrossingFigure(FigureNumber, To, new Tuple<int, int>(To.Item1 + (-2), d)))
                                        {
                                            InsertNewMove(FigureNumber, To);
                                            CrossCount = 0;
                                            break;
                                        }
                                    }
                                    CrossCount = 0;
                                }
                                else  {  return true; }
                                return true;
                            }
                        }
                    }
                }
           /*  */
            return false;
        }
        public bool InsertNewMove(int FigureNumber, Tuple<int, int> To)
        {
            while (true)
            {
                Console.WriteLine("---------" + FigureNumber + "Player  turn again------/n");
                ShowSquares();

                Console.WriteLine("Where to move?");
                var NextMove = Game.GetNumbers(Convert.ToInt32(Console.ReadLine()));

                CrossCount = 0;
                if (CrossingFigure(FigureNumber, To, NextMove))  { return true; }
            }
        }
        public void ShowSquares()
        {
            Console.WriteLine("##############################");
            Console.Write("  ");
            for (var i = 1; i <= Width; i++) { Console.Write(i + " "); };
            Console.WriteLine("\n__________________");
            for (var i = Width; i>= 1; i--)
            {
                Console.Write(i + "|");
                for (var j = 1; j <= Width; j++)
                {
                    Console.Write(BoardValue[i, j] + " ");
                }
                Console.WriteLine("|" + i);
            }
            Console.WriteLine("__________________");
            Console.Write("  ");
            for (var i = 1; i <= Width; i++) { Console.Write(i + " "); };
            Console.WriteLine();
            Console.WriteLine("##############################");
        }
    }
    public class Game
    {
        public Board Board { get; private set; }
        public Game(Board Board)
        {
            this.Board = Board;
        }

        public static Tuple<int, int> GetNumbers(int Number)
        {
            int First = Number / 10;
            int Second = Number - (First * 10);
            return new Tuple<int, int>(First, Second);
        }

        private void MoveFigure(int from, int to)
        {
            var fromLocation = GetNumbers(from);
            var toLocation = GetNumbers(to);
        }

        private bool CheckIfIfExist(int nubmer)
        {
            return true;
        }

        public void PlayGame()
        {
            Console.WriteLine("LET'S START A NEW GAME! Please insert 444 to start/EXIT - 555");
            int Start = Convert.ToInt32(Console.ReadLine());
            if (Start == 555)
            {
                Environment.Exit(0);
            }
            Console.WriteLine("Lets Begin the Game hahaha");
            int Player = 1;
            while (true)
            {
                Board.ShowSquares();
                Console.WriteLine("##### Player" + Player  + " #####\nWhich figure to move");
                var fromTuple = GetNumbers(Convert.ToInt32(Console.ReadLine()));

                Console.WriteLine("Where to move?");
                var toTuple = GetNumbers(Convert.ToInt32(Console.ReadLine()));

                if (!Board.CrossingFigure(Player, fromTuple, toTuple)) /*if not true - there are no ways of crossing any figure */
                { /*moving to check other directions */
                    if (Board.CheckIfIsItAllowedToMove(Player, fromTuple, toTuple))
                    {
                        Console.WriteLine("Success");
                    }
                    else
                    {
                        Console.WriteLine("Wrong coordinates");
                        Player = Player == 1 ? 2 : 1;
                    }
                }
                else  {   Console.WriteLine("You just thrown out an opponent's figure"); }
                Player = Player == 1 ? 2 : 1;
            }
        }
    }
}



/* if(BoardValue[From.Item1 + 1, From.Item2 + 1] != FigureNumber 
                  && BoardValue[From.Item1 + 1, From.Item2 + 1] != 0 
                  && BoardValue[From.Item1 + 2, From.Item2 + 2] == 0)
              {
                  BoardValue[From.Item1 + 1, From.Item2 + 1] = 0;
                  BoardValue[From.Item1 + 2, From.Item2 + 2] = FigureNumber;
                  BoardValue[From.Item1, From.Item2] = 0;
                  return true;
              }
              if (BoardValue[From.Item1 + 1, From.Item2 - 1] != FigureNumber
                && BoardValue[From.Item1 + 1, From.Item2 - 1] != 0
                && BoardValue[From.Item1 + 2, From.Item2 - 2] == 0)
              {
                  BoardValue[From.Item1 + 1, From.Item2 - 1] = 0;
                  BoardValue[From.Item1 + 2, From.Item2 - 2] = FigureNumber;
                  BoardValue[From.Item1, From.Item2] = 0;
                  return true;
              }
              if (BoardValue[From.Item1 - 1, From.Item2 + 1] != FigureNumber
                && BoardValue[From.Item1 - 1, From.Item2 + 1] != 0
                && BoardValue[From.Item1 - 2, From.Item2 + 2] == 0)
              {
                  BoardValue[From.Item1 - 1, From.Item2 + 1] = 0;
                  BoardValue[From.Item1 - 2, From.Item2 + 2] = FigureNumber;
                  BoardValue[From.Item1, From.Item2] = 0;
                  return true;
              }
              if (BoardValue[From.Item1 - 1, From.Item2 - 1] != FigureNumber
                && BoardValue[From.Item1 - 1, From.Item2 - 1] != 0
                && BoardValue[From.Item1 - 2, From.Item2 - 2] == 0)
              {
                  BoardValue[From.Item1 - 1, From.Item2 - 1] = 0;
                  BoardValue[From.Item1 - 2, From.Item2 - 2] = FigureNumber;
                  BoardValue[From.Item1, From.Item2] = 0;
                  return true;
              }*/
